-- Banking Transaction & Fraud Analysis
-- Run in MySQL after creating the database and importing cleaned_transactions.csv.
-- Example table definition:
CREATE DATABASE IF NOT EXISTS banking_analytics;
USE banking_analytics;

CREATE TABLE IF NOT EXISTS transactions (
    transaction_id VARCHAR(20) PRIMARY KEY,
    customer_id VARCHAR(20),
    transaction_date DATE,
    transaction_amount DECIMAL(14,2),
    transaction_type VARCHAR(10),
    payment_mode VARCHAR(30),
    location VARCHAR(50),
    review_flag VARCHAR(20)
);

-- 1. Total transaction count and value
SELECT COUNT(*) AS total_transactions,
       SUM(transaction_amount) AS total_transaction_value
FROM transactions;

-- 2. Average, minimum, and maximum transaction amount
SELECT AVG(transaction_amount) AS average_amount,
       MIN(transaction_amount) AS minimum_amount,
       MAX(transaction_amount) AS maximum_amount
FROM transactions;

-- 3. Monthly transaction trends
SELECT DATE_FORMAT(transaction_date, '%Y-%m') AS transaction_month,
       COUNT(*) AS transaction_count,
       SUM(transaction_amount) AS total_amount
FROM transactions
GROUP BY DATE_FORMAT(transaction_date, '%Y-%m')
ORDER BY transaction_month;

-- 4. Payment mode analysis
SELECT payment_mode, COUNT(*) AS transaction_count,
       SUM(transaction_amount) AS total_amount
FROM transactions
GROUP BY payment_mode
ORDER BY transaction_count DESC;

-- 5. Customer transaction frequency
SELECT customer_id, COUNT(*) AS transaction_count,
       SUM(transaction_amount) AS total_amount
FROM transactions
GROUP BY customer_id
ORDER BY transaction_count DESC;

-- 6. Records flagged for review (not confirmed fraud)
SELECT *
FROM transactions
WHERE review_flag = 'Review'
ORDER BY transaction_amount DESC;
