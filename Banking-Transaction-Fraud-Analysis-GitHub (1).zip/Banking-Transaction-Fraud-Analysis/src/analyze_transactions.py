from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "bank_transactions.csv"
REPORTS = ROOT / "reports"
REPORTS.mkdir(exist_ok=True)

df = pd.read_csv(DATA, parse_dates=["transaction_date"])
print(f"Raw rows: {len(df)}")
print("Missing values before cleaning:")
print(df.isna().sum())

# Basic data cleaning
df = df.drop_duplicates(subset=["transaction_id"]).copy()
df["location"] = df["location"].fillna("Unknown")
df["transaction_amount"] = pd.to_numeric(df["transaction_amount"], errors="coerce")
df = df.dropna(subset=["transaction_amount", "transaction_date"])
df = df[df["transaction_amount"] >= 0].copy()

# IQR-based review flag. This is a screening indicator, not a fraud verdict.
q1 = df["transaction_amount"].quantile(0.25)
q3 = df["transaction_amount"].quantile(0.75)
iqr = q3 - q1
upper_bound = q3 + 1.5 * iqr
df["review_flag"] = np.where(df["transaction_amount"] > upper_bound, "Review", "Regular")

# Summary outputs
df["month"] = df["transaction_date"].dt.to_period("M").astype(str)
monthly = (df.groupby("month", as_index=False)
           .agg(transaction_count=("transaction_id", "count"),
                total_amount=("transaction_amount", "sum"),
                average_amount=("transaction_amount", "mean")))
payment = (df.groupby("payment_mode", as_index=False)
           .agg(transaction_count=("transaction_id", "count"),
                total_amount=("transaction_amount", "sum")))
review = df[df["review_flag"] == "Review"].sort_values(
    "transaction_amount", ascending=False
)

df.to_csv(REPORTS / "cleaned_transactions.csv", index=False)
monthly.to_csv(REPORTS / "monthly_summary.csv", index=False)
payment.to_csv(REPORTS / "payment_mode_summary.csv", index=False)
review.to_csv(REPORTS / "transaction_review.csv", index=False)

print("\nAnalysis summary")
print(f"Clean transactions: {len(df):,}")
print(f"Total amount: ₹{df['transaction_amount'].sum():,.2f}")
print(f"Average amount: ₹{df['transaction_amount'].mean():,.2f}")
print(f"Records flagged for review: {len(review):,}")
print(f"IQR review threshold: ₹{upper_bound:,.2f}")
print("\nReports saved in:", REPORTS)
