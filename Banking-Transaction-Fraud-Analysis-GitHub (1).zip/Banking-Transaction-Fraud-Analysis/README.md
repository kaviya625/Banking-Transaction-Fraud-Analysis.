# Banking Transaction & Fraud Analysis

A beginner-friendly **data analytics portfolio project** using Python, Pandas, NumPy, SQL/MySQL, and Power BI.

> **Dataset notice:** This repository uses a synthetic/demo dataset generated for learning. It contains no real customer or banking information. The project flags unusual high-value transactions for **review**; a flag is not proof of fraud.

## Project objective

Explore transaction activity, clean transaction records, calculate summary metrics, query data with SQL, and prepare visual outputs that can be used in a Power BI dashboard.

## Technology stack

- **Python** – project scripting and analysis
- **Pandas** – reading, cleaning, and summarising tabular data
- **NumPy** – numerical calculations and a simple outlier threshold
- **SQL / MySQL** – table structure and example analytical queries
- **Power BI** – optional interactive dashboard built by importing the cleaned CSV

## Repository structure

```text
Banking-Transaction-Fraud-Analysis/
├── data/
│   └── bank_transactions.csv
├── reports/
│   ├── monthly_summary.csv
│   ├── payment_mode_summary.csv
│   └── transaction_review.csv
├── sql/
│   └── analysis_queries.sql
├── src/
│   └── analyze_transactions.py
├── dashboard_preview.png
├── requirements.txt
└── README.md
```

## Dataset columns

| Column | Description |
|---|---|
| transaction_id | Unique transaction identifier |
| customer_id | Synthetic customer identifier |
| transaction_date | Date of transaction |
| transaction_amount | Transaction amount in INR |
| transaction_type | Credit or Debit |
| payment_mode | UPI, Card, Net Banking, or ATM |
| location | Synthetic transaction location |

## Run the project

1. Install Python 3.9 or later.
2. Open a terminal in this repository.
3. Install dependencies:

```bash
pip install -r requirements.txt
```

4. Run the analysis:

```bash
python src/analyze_transactions.py
```

The script creates cleaned data and summary CSV files inside `reports/`.

## Analysis performed

- Checks missing values and duplicate records
- Removes duplicate transaction IDs
- Fills missing location values with `Unknown`
- Calculates total, average, minimum, and maximum transaction amounts
- Summarises transaction volume by month and payment mode
- Flags unusually high transaction amounts using the IQR method

### Important limitation

The IQR rule is a simple statistical screening technique. It does not establish that a transaction is fraudulent. Real fraud detection requires additional context, validated labels, domain rules, model evaluation, and investigation.

## SQL / MySQL

Open `sql/analysis_queries.sql` and run the queries after creating the table and importing the cleaned CSV into MySQL. The file includes queries for transaction totals, monthly activity, payment-mode summaries, customer activity, and high-value transactions.

## Power BI dashboard

To build an interactive Power BI report:

1. Open Power BI Desktop.
2. Select **Get Data → Text/CSV**.
3. Import `reports/cleaned_transactions.csv` after running the Python script.
4. Create KPI cards for transaction count, total amount, and average amount.
5. Add a line chart for monthly transaction volume.
6. Add a bar chart for payment mode.
7. Add a donut chart for Credit vs Debit.
8. Add a table using the `review_flag` column to inspect records flagged for review.
9. Add slicers for transaction date, payment mode, transaction type, and location.

The included PNG is a **static illustrative preview**, not an interactive Power BI report and not evidence of measured project results.

## Suggested interview explanation

"I analysed a synthetic banking transaction dataset using Python and Pandas to clean and organise the records. I used NumPy for numerical analysis and SQL queries to summarise transaction activity, customer frequency, and high-value records. I prepared summary files for visualisation in Power BI. The project demonstrates a basic analytics workflow and uses an IQR-based rule to flag unusual values for further review, rather than claiming that those transactions are confirmed fraud."

## Future improvements

- Add a labelled public fraud dataset and evaluate a classification model
- Compare statistical rules with machine-learning approaches
- Build an interactive Power BI `.pbix` report
- Add tests and data-quality checks
